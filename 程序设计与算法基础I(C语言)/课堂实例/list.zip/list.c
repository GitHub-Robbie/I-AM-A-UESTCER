#include "list.h"

void init(listptr l)
{
    l->head.next = NULL;
}