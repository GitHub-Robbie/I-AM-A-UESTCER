#include <stdio.h>
#include <stdlib.h>

typedef int value_type;

typedef struct _node
{
    value_type data;
    struct _node *next;
} node;
typedef node* nodeptr;

typedef struct
{
    node head;
} list;
typedef list* listptr;

extern void init(listptr);