#include <stdio.h>

#include "list.h"

list L;

int main()
{
    init(&L);

    return 0;    
}